﻿namespace DerivativeVisualizerModel
{
    public enum TokenType
    {
        Number,
        Variable,
        Operator,
        LeftParen,
        RightParen,
        Function,
        Comma,
    }
}